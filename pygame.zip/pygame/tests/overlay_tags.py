# Overlay support was removed in SDL 2
__tags__ = ["SDL2_ignore"]
